#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Сбор истории ПУБЛИЧНОГО канала с веб-страницы t.me/s/<канал>.

Не требует экспорта и логина. Работает только для публичных каналов.
Юзернейм канала берётся из config.json (поле "channel", без @).

Запуск: python3 scrape_history.py                      # добор с даты последнего сохранённого поста
        python3 scrape_history.py --since 2026-01-01   # всё начиная с даты
        python3 scrape_history.py --channel имя_канала # если config.json недоступен (облачная сессия)
"""
import html
import json
import os
import re
import subprocess
import sys
import time

BASE = os.path.dirname(os.path.abspath(__file__))
POSTS_DIR = os.path.join(BASE, "posts")
CONFIG_PATH = os.path.join(BASE, "config.json")


def load_channel():
    """Юзернейм канала: --channel в аргументах, иначе поле channel в config.json."""
    if "--channel" in sys.argv:
        idx = sys.argv.index("--channel") + 1
        if idx >= len(sys.argv):
            sys.exit("После --channel укажи юзернейм канала, например: --channel my_channel")
        raw = sys.argv[idx]
    else:
        try:
            with open(CONFIG_PATH, encoding="utf-8") as f:
                config = json.load(f)
        except FileNotFoundError:
            sys.exit(
                "Не найден config.json рядом со скриптом.\n"
                "Скопируй config.example.json в config.json и впиши юзернейм канала в поле \"channel\" "
                "(или передай его аргументом: --channel имя_канала)."
            )
        except json.JSONDecodeError as e:
            sys.exit(f"config.json повреждён (ошибка JSON: {e}). Проверь кавычки и запятые.")
        raw = config.get("channel", "")

    raw = (raw or "").strip()
    # Разрешаем вписать «@канал» или «https://t.me/канал» — приводим к чистому юзернейму.
    raw = re.sub(r"^https?://t\.me/(s/)?", "", raw).strip("/")
    raw = raw.lstrip("@")
    if not raw or "ВСТАВЬ" in raw:
        sys.exit(
            "В config.json не задан канал. Впиши юзернейм канала (без @) в поле \"channel\", например:\n"
            '  { "bot_token": "...", "channel": "my_channel" }'
        )
    if not re.fullmatch(r"[A-Za-z0-9_]{4,}", raw):
        sys.exit(f"Странный юзернейм канала: «{raw}». Нужны только латиница, цифры и _, без @ и ссылок.")
    return raw


CHANNEL = load_channel()

os.makedirs(POSTS_DIR, exist_ok=True)

since = ""
if "--since" in sys.argv:
    idx = sys.argv.index("--since") + 1
    if idx >= len(sys.argv):
        sys.exit("После --since укажи дату в формате ГГГГ-ММ-ДД, например: --since 2026-01-01")
    since = sys.argv[idx]
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", since):
        sys.exit(f"Дата «{since}» не в формате ГГГГ-ММ-ДД.")
else:
    # Без --since продолжаем с даты последнего сохранённого поста
    existing = sorted(n for n in os.listdir(POSTS_DIR) if n.endswith(".md"))
    if existing:
        since = existing[-1][:10]


def fetch(before=None):
    url = f"https://t.me/s/{CHANNEL}"
    if before:
        url += f"?before={before}"
    r = subprocess.run(["curl", "-s", "--max-time", "60", url],
                       capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit(f"Сетевая ошибка: {r.stderr.strip()}")
    return r.stdout


def strip_html(fragment):
    fragment = re.sub(r"<br\s*/?>", "\n", fragment)
    fragment = re.sub(r"<[^>]+>", "", fragment)
    return html.unescape(fragment).strip()


MEDIA_MARKERS = [
    ("tgme_widget_message_photo_wrap", "фото"),
    ("tgme_widget_message_video_player", "видео"),
    ("tgme_widget_message_roundvideo", "кружок"),
    ("tgme_widget_message_voice", "голосовое"),
    ("tgme_widget_message_document", "файл"),
    ("tgme_widget_message_poll", "опрос"),
    ("tgme_widget_message_sticker", "стикер"),
]

channel_title = ""
saved = 0
skipped_old = False
before = None
seen_pages = set()
first_page = True

while True:
    page = fetch(before)
    if first_page:
        first_page = False
        if "tgme_widget_message_wrap" not in page:
            sys.exit(
                f"На странице https://t.me/s/{CHANNEL} нет постов.\n"
                "Проверь: канал публичный? юзернейм в config.json написан верно (без @)?"
            )
    if not channel_title:
        m = re.search(r'<meta property="og:title" content="([^"]*)"', page)
        channel_title = html.unescape(m.group(1)) if m else CHANNEL

    blocks = re.split(r'<div class="tgme_widget_message_wrap', page)[1:]
    ids_on_page = []
    for block in blocks:
        m_id = re.search(r'data-post="%s/(\d+)"' % re.escape(CHANNEL), block)
        if not m_id:
            continue
        msg_id = int(m_id.group(1))
        ids_on_page.append(msg_id)

        m_date = re.findall(r'<time[^>]*datetime="([^"]+)"', block)
        date_iso = m_date[-1] if m_date else ""
        day = date_iso[:10]
        hhmm = date_iso[11:16]
        if since and day and day < since:
            skipped_old = True
            continue

        m_text = re.search(
            r'<div class="tgme_widget_message_text[^"]*"[^>]*>(.*?)</div>',
            block, re.DOTALL)
        text = strip_html(m_text.group(1)) if m_text else ""
        media = [ru for marker, ru in MEDIA_MARKERS if marker in block]
        if not text and not media:
            continue

        lines = [
            "---",
            f"id: {msg_id}",
            f"date: {day} {hhmm}",
            f"channel: {channel_title}",
        ]
        if media:
            lines.append(f"media: {', '.join(media)}")
        lines += ["---", "", text, ""]
        filename = f"{day}_{msg_id:05d}.md"
        with open(os.path.join(POSTS_DIR, filename), "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        saved += 1

    if not ids_on_page:
        break
    min_id = min(ids_on_page)
    if skipped_old or min_id in seen_pages or min_id <= 1:
        break
    seen_pages.add(min_id)
    before = min_id
    time.sleep(0.7)

print(f"Канал: {channel_title} (@{CHANNEL})")
print(f"Сохранено постов: {saved}" + (f" (с {since})" if since else ""))

#!/bin/bash
# Полное обновление архива постов: облако → бот → публичная страница канала → облако.
# Папка должна лежать в ~/tg-assistant (не на Рабочем столе — иначе launchd её не увидит).
cd "$HOME/tg-assistant" || exit 1
python3 sync_channel.py          # git pull + новые посты через бота (getUpdates)
python3 scrape_history.py        # добор пропусков с t.me/s/<канал> (канал берётся из config.json)
if [ -n "$(git status --porcelain)" ]; then
  git add -A && git commit -q -m "sync: автообновление постов" && git push -q \
    && echo "Изменения отправлены в облако (GitHub)."
fi
